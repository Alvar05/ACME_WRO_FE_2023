//Definición M5Stack para FE 2021-2022

//Driver ESC Motor 
#define ESC 16
#define ENC_A 34 // encoder Rueda A  **tiene PULL_UP externo**
#define ENC_B 35 // encoder Rueda B  **no tiene (hay que ponerlo) PULL_UP externo y no se le puede poner interno**
#define ENC_C 36 // encoder Motor C  **no tiene (hay que ponerlo) PULL_UP externo y no se le puede poner interno**
float diametroRueda = 2.9; //Diametro de las ruedas en cm 
bool sentidoA = true;
bool sentidoB = true;
bool sentidoC = true;
volatile long encoderAcontador = 10;
volatile long encoderBcontador = 15;
volatile long encoderCcontador = 20;
unsigned long incrementoB = micros();
unsigned long incrementoC = micros();
const long incrementoMinimoEntrePulsos = 40000; // Hay que revisar este valor
int velocidad;

//PID
float error, proporcional, integral, derivativo, errorSuma, giro, errorAnterior;

//BT
bool estadoBeep = false;
long startBeep = 0; 
bool estadoBT = true;
int velBT = 7; //Velocidad predeterminada
int velMinBT = 0;
float kpBT = 0;
float kiBT = 0;
float kdBT = 0;
int sectorIZQ = 0;
int sectorCEN = 0;
int sectorDER = 0;


//MPU6050
#define OUTPUT_READABLE_YAWPITCHROLL
#define INTERRUPT_PIN 13

// MPU control/status vars
bool dmpReady = false;  // set true if DMP init was successful
uint8_t mpuIntStatus;   // holds actual interrupt status byte from MPU
uint8_t devStatus;      // return status after each device operation (0 = success, !0 = error)
uint16_t packetSize;    // expected DMP packet size (default is 42 bytes)
uint16_t fifoCount;     // count of all bytes currently in FIFO
uint8_t fifoBuffer[64]; // FIFO storage buffer
float euler[3];         // [psi, theta, phi]    Euler angle container
float ypr[3];           // [yaw, pitch, roll]   yaw/pitch/roll container and gravity vector
volatile bool mpuInterrupt = false;     // indicates whether MPU interrupt pin has gone high
bool debugYPR = false;  // Imprime YPR

//Memorizado del recorrido
int disPared[] = {50, 90, 50, 50}; // 90(cm) si la pared correspondiente esta alargada, 50(cm) si no. (Desde el centro de la recta)(Contrarreloj clasificatoria)
